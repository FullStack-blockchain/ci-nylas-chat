<footer>
  <div class="pull-right">
  	<?php echo $this->config->item('footer_text'); ?>
  </div>
  <div class="clearfix"></div>
</footer>
