<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 * XWB Purchasing
 *
 * @package     XWB Purchasing
 * @author      Jay-r Simpron
 * @copyright   Copyright (c) 2017, Jay-r Simpron
 */

/**
 * Main model class for Member
 */
class Xwb_member_model extends Xwb_custom_model
{
    /**
     * Run parent constructor
     */
    public function __construct()
    {
        parent::__construct();
    }
}
