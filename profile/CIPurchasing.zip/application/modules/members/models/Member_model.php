<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * XWB Purchasing
 * 
 * @package 	XWB Purchasing
 * @author      Jay-r Simpron
 * @copyright   Copyright (c) 2017, Jay-r Simpron
 */

/**
 * Member Model Class
 * 
 * You can override all the parent method here.
 */
class Member_model extends Xwb_member_model {
	/**
	 * Run parent constructor
	 */
	function __construct(){
		parent::__construct();
	}

}