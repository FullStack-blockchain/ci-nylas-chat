<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * XWB Purchasing
 * 
 * @package 	XWB Purchasing
 * @author      Jay-r Simpron
 * @copyright   Copyright (c) 2017, Jay-r Simpron
 */



/**
 * Settings Model
 * 
 * You can override all the parent method here.
 */
class Settings_model extends Xwb_settings_model {

	/**
	 * Run parent construct
	 * 
	 * @return Null
	 */
	function __construct(){
		parent::__construct();
	}



}