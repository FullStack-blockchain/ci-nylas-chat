<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * XWB Purchasing
 * 
 * @package     XWB Purchasing
 * @author      Jay-r Simpron
 * @copyright   Copyright (c) 2017, Jay-r Simpron
 */


/**
 * Canvassed Model Class
 * 
 * You can override all the parent method here.
 */
class Canvassed_model extends Xwb_canvassed_model {
    /**
     * Run parent constructor
     */
    function __construct(){
        parent::__construct();
    }
}