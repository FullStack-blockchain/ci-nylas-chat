<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'admin',
    'pass' => '$1$LdYoIsO2$gq/ZesgbGy5Yx2Os.YhLU0',
    'role' => 'superadmin',
  ),
  1 => 
  array (
    'name' => 'test',
    'pass' => '$1$T62FEMlC$fRrcG6zMrp7zRfdtlYkBk0',
    'role' => 'admin',
  ),
);
