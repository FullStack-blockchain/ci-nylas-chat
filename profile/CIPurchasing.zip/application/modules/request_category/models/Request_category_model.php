<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * XWB Purchasing
 * 
 * @package 	XWB Purchasing
 * @author      Jay-r Simpron
 * @copyright   Copyright (c) 2017, Jay-r Simpron
 */


/**
 * Request Category Model Class
 * 
 * You can override all the parent method here.
 */
class Request_category_model extends Xwb_request_category_model {

	/**
	 * Run parent constructor
	 */
	function __construct(){
		parent::__construct();
	}

}