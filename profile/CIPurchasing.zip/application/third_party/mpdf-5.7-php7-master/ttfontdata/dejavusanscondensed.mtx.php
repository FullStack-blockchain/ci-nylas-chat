<?php
$name='DejaVuSansCondensed';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-918 -415 1513 1167]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='/home/projects/purchasing/application/third_party/mpdf-5.7-php7-master/ttfonts/DejaVuSansCondensed.ttf';
$TTCfontID='0';
$originalsize=555944;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusanscondensed';
$panose=' 0 0 2 b 6 6 3 8 4 2 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>