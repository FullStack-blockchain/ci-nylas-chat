<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * XWB Purchasing
 * 
 * @package 	XWB Purchasing
 * @author      Jay-r Simpron
 * @copyright   Copyright (c) 2017, Jay-r Simpron
 */


/**
 * Users Controller
 * 
 * All users method for this module will be placed here
 * You can override all the functions from the admin module here
 */
class User extends Xwb_user {

	/**
	 * Run parent construct
	 * 
	 * @return Null
	 */
	public function __construct(){
		parent::__construct();

	}
	

}
