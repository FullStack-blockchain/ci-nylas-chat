<footer>
  <div class="pull-right">
    XWB Purchasing - Developed by <a target="_blank" href="http://www.extremewebevolution.com">eXWeb</a>
  </div>
  <div class="clearfix"></div>
</footer>